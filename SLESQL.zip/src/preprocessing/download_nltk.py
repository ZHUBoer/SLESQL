# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

# -*- coding: utf-8 -*-
"""
# @Time    : 2019/1/29
# @Author  : Jiaqi&Zecheng
# @File    : download_nltk.py
# @Software: PyCharm
"""
import nltk
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

